// Dashboard.js
// Content pallete for the /dashboard route.

import React from 'react';
import { Redirect, Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import {
  Typography,
} from '@material-ui/core';

class Dashboard extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // TODO
    };
  }

  render() {
    const {
      classes,
      title,
    } = this.props;

    const user = localStorage.getItem("name");
    console.log("user: " + user);

    return (
      <div className={classes.root}>
        <Typography variant="display1">Dashboard</Typography>
        <p>You are authenticated as: {user}</p>
      </div>
    );
  }
}

const styles = theme => ({
  root: { }
});

export default withStyles(styles)(Dashboard);
