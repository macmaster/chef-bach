// PostsList.js
// serves list component for posts resource.

import React from 'react';
import {
  List,
  Datagrid,
  TextField,
  ReferenceField,
  EditButton,
} from 'react-admin';

import PostFilter from 'posts/PostFilter';

export default function PostsList(props) {
  return (
    <List {...props} filters={<PostFilter />}>
      <Datagrid>
        <TextField source='id' />
        <ReferenceField label="User" source="userId" reference="users">
          <TextField source="name" />
        </ReferenceField>
        <TextField source='title' />
        <TextField source='body' />
        <EditButton />
      </Datagrid>
    </List>
  );
}
