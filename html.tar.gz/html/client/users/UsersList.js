// UsersList.js
// serves list component for users resource.

import React from 'react';
import {
  List,
  Datagrid,
  TextField,
  EmailField
} from 'react-admin';

export default function UsersList(props) {
  return (
    <List {...props} >
      <Datagrid>
        <TextField source='id' />
        <TextField source='name' />
        <TextField source='username' />
        <EmailField source='email' />
      </Datagrid>
    </List>
  );
}
