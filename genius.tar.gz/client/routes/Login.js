// Login.js
// Content pallette for the /login route.

import LoginForm from 'forms/LoginForm';

import React from 'react';
import { Redirect } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      redirect: props.cookie,
    };
  }

  render() {
    if (this.state.redirect) {
      return <Redirect exact push to="/dashboard" />;
    } else {
      console.log("redirect: ", this.state.redirect);
    }

    const { classes, action, title, } = this.props;

    return (
      <div className={classes.root}>
        <div className={classes.flex}>
          <LoginForm action={action} title={title}
            setCookie={this.props.setCookie} />
        </div>
      </div>
    );
  }

}

const styles = theme => ({
  root: {
    display: "block",
    margin: "auto",
  },

  flex: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignContent: "center",
    height: "100vh",
    textAlign: "center",
  },
});

export default withStyles(styles)(Login);
