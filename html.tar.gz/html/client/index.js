// index.js
// Application entry point.

import React from 'react';
import { render } from 'react-dom';

import { Admin, Resource } from 'react-admin';
import jsonServerProvider from 'ra-data-json-server';
import authProvider from 'providers/authProvider';

import Dashboard from 'dashboard/Dashboard'

import PostsIcon from '@material-ui/icons/Book';
import PostsList from 'posts/PostsList';
import PostEdit from 'posts/PostEdit';
import PostCreate from 'posts/PostCreate';

import UsersIcon from '@material-ui/icons/People';
import UsersList from 'users/UsersList';

// const geniusProvier =
//   jsonServerProvider('http://genius.hadoop.bloomberg.com');

var content = render(
  <Admin dashboard={Dashboard}
    authProvider={authProvider}
    dataProvider={jsonServerProvider('http://jsonplaceholder.typicode.com')}>
      <Resource name="posts" icon={PostsIcon} list={PostsList} edit={PostEdit} create={PostCreate} />
      <Resource name="users" icon={UsersIcon} list={UsersList} />
  </Admin>,
  document.getElementById('content')
);
