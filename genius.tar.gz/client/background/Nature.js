// Nature.js
// Nature Background Image.

import React from 'react';
import { withStyles } from '@material-ui/core/styles'

const styles = theme => ({
  root: {
    position: "absolute",
    top: "0",
    left: "0",
    zIndex: "-999999",
    width: "100%",
    height: "100%",
    opacity: "0.5",
    backgroundAttachment: "fixed",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
    backgroundImage: "url('/images/nature.jpg')",
  },
});

function Nature(props) {
  return (
    <div className={props.classes.root} />
  );
}

export default withStyles(styles)(Nature);
