// PostEdit.js
// Form to edit a post.

import React from 'react';
import {
  Edit,
  SimpleForm,
  DisabledInput,
  TextInput,
  LongTextInput,
  ReferenceInput,
  SelectInput,
} from 'react-admin';

export default function PostEdit(props) {
  return (
    <Edit {...props} >
      <SimpleForm>
        <DisabledInput source='id' />
        <ReferenceInput label="User" source="userId" reference="users">
          <SelectInput optionText="name" />
        </ReferenceInput>
        <TextInput source='title' />
        <LongTextInput source='body' />
      </SimpleForm>
    </Edit>
  );
}
