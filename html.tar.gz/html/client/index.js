// index.js
// Application entry point.

import React from 'react';
import { render } from 'react-dom';

import { Admin, Resource } from 'react-admin';
import jsonServerProvider from 'ra-data-json-server';

import PostsList from 'posts/PostsList';
import UsersList from 'users/UsersList';

// const geniusProvier =
//   jsonServerProvider('http://genius.hadoop.bloomberg.com');

var content = render(
  <Admin dataProvider={jsonServerProvider('http://jsonplaceholder.typicode.com')}>
      <Resource name="posts" list={PostsList} />
      <Resource name="users" list={UsersList} />
  </Admin>,
  document.getElementById('content')
);
