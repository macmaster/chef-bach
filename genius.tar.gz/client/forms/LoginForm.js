// LoginForm.js
// Form for submitting login requests.

import React from 'react';
import { Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import { 
  Button,
  LinearProgress,
  Paper, 
  TextField,
  Typography,
} from '@material-ui/core';

class LoginForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // fields
      username: null,
      password: null,

      error: null,
      errors: {
        username: false,
        password: false,
      }
    };
  }

  render() {
    const { classes, } = this.props;

    let progress = this.state.loading && (
      <LinearProgress className={classes.progress} />
    );

    let errorMessage = this.state.error && (
      <Typography className={classes.error}>
        {this.state.error}
      </Typography>
    );

    let form = (
      <form action={this.props.action} className={classes.form}>
        <Typography variant="display1" align="center">
          {this.props.title}</Typography>
        <TextField name="username" placeholder="username" 
          required error={this.state.errors.username} autoFocus
          className={classes.input} onChange={e => this.onChange(e)} />
        <TextField name="password" placeholder="password"
          required error={this.state.errors.password} type="password"
          className={classes.input} onChange={e => this.onChange(e)} />
        <Button color="primary" variant="raised" type="submit"
          className={classes.submit} onClick={e => this.onSubmit(e)}>
          Login</Button>
        <Link to="/register">
          <Button color="secondary" variant="raised"
            className={classes.submit}>
            Register</Button>
        </Link>
        {errorMessage}
      </form>
    );

    return (
      <Paper className={classes.paper}>
        {progress}
        {form}
      </Paper>
    );
  }

  onSubmit(e) {
    e.preventDefault();
    this.validate();
    this.setState({loading: true});
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value});
  }

  validate() {
    setTimeout(() => {
      this.setState({loading: false});
      if (this.login(this.state.username, this.state.password)) {
        console.log("state: ", this.state);
        localStorage.setItem("name", this.state.username);
        localStorage.setItem("cookie", this.state.password);
        this.props.setCookie(localStorage.getItem("cookie"));
        this.setState({redirect: true});
      } else {
        let reducer = (acc, curr) => Object.assign(acc, { [curr]: true });
        let error = "Wrong password, try again or click register to sign up.";
        let errors = Object.keys(this.state.errors).reduce(reducer, {});
        console.log("errors:", errors);
        this.setState({error, errors});
      }
    }, 500);
  }

  login(name, password) {
    // TODO: Authenticate with Web Service.
    const passwords = {
      rmacmaster: "Physics17",
      aanand59: "password",
      rali43: "password",
      acpi: "naruto1",
    };
    console.log(`password: ${password}`);
    console.log(`actual password: ${passwords[name]}`);
    return (password === passwords[name]);
  }

}

const styles = theme => ({
  paper: {
    margin: "auto",
    width: "100%",
    height: "100%",
    maxWidth: "400px", 
    maxHeight: "400px", 
  },

  form: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },

  input: {
    margin: "10px",
    width: "80%",
    margin: "10px auto",
  },

  submit: {
    width: "80%",
    margin: "15px auto",
  },

  progress: {
    borderRadius: "5px",
    opacity: "0.5",
  },

  error: {
    color: "red",
  },
});

export default withStyles(styles)(LoginForm);
