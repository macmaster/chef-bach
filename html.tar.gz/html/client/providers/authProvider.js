// authProvider.js
// Provides authentication service.

import React from 'react';

import {
  AUTH_LOGIN,
  AUTH_LOGOUT,
  AUTH_ERROR,
  AUTH_CHECK,
} from 'react-admin';

export default function authProvider(type, params) {
  switch(type) {
    case AUTH_LOGIN:
      return authLogin(params);
    case AUTH_LOGOUT:
      return authLogout(params);
    case AUTH_ERROR:
      return authError(params);
    case AUTH_CHECK:
      return authCheck(params);
    default:
      return Promise.reject('Unknown authentication method!');
  }
}

function authLogin({ username, password }) {
  const vault = {
    rmacmaster: 'password',
    admin: 'password',
  };

  if (password === vault[username]) {
    localStorage.setItem('username', username);
    return Promise.resolve();
  } else {
    return Promise.reject();
  }
}

function authLogout() {
  localStorage.removeItem('username');
  return Promise.resolve();
}

function authError({ status }) {
  if (status == 401 || status == 403) {
    localStorage.removeItem('username');
    return Promise.reject();
  } else {
    return Promise.resolve();
  }
}

function authCheck() {
  let username = localStorage.getItem('username');
  return username ? Promise.resolve() : Promise.reject();
}

