// PostsList.js
// serves list component for posts resource.

import React from 'react';
import { List, Datagrid, TextField } from 'react-admin';

export default function PostsList(props) {
  return (
    <List {...props} >
      <Datagrid>
        <TextField source='id' />
        <TextField source='title' />
        <TextField source='body' />
      </Datagrid>
    </List>
  );
}
