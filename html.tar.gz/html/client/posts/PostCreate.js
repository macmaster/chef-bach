// PostCreate.js
// Form to create a post.

import React from 'react';
import {
  Create,
  SimpleForm,
  TextInput,
  LongTextInput,
  ReferenceInput,
  SelectInput,
} from 'react-admin';

export default function PostCreate(props) {
  return (
    <Create {...props} >
      <SimpleForm>
        <ReferenceInput label="User" source="userId" reference="users">
          <SelectInput optionText="name" />
        </ReferenceInput>
        <TextInput source='title' />
        <LongTextInput source='body' />
      </SimpleForm>
    </Create>
  );
}
