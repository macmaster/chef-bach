// Dashboard.js
// Landing page for admin panel.

import React from 'react';

import {
  Card,
  CardHeader,
  CardContent,
} from '@material-ui/core';

export default function Dashboard(props) {
  return (
    <Card>
      <CardHeader title="Welcome to the BACH Platform!" />
      <CardContent>File a DRQS with Group 1236 for assistance</CardContent>
    </Card>
  );
}
